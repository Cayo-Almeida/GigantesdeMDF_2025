var main_8c =
[
    [ "F_CPU", "main_8c.html#a43bafb28b29491ec7f871319b5a3b2f8", null ],
    [ "adc_init", "main_8c.html#a2b815e6730e8723a6d1d06d9ef8f31c0", null ],
    [ "adc_read", "main_8c.html#a433119dfcbc822d888666197007a4f30", null ],
    [ "ISR", "main_8c.html#a7cfcbe42bd266750aeb6e5d71e5ea479", null ],
    [ "main", "main_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "moverTanque", "main_8c.html#afebbadafe3848a6c3d88668f9fe4298e", null ],
    [ "recebeuDisparo", "main_8c.html#a33ce7e068b28ea685c11168275b40d17", null ],
    [ "timer0_init", "main_8c.html#a99eb04bf8fed2beecfb3cb74451416c5", null ],
    [ "timer2_init", "main_8c.html#a2cd8cee0c5bd8d8b2f528216f7dd487d", null ],
    [ "adc_flag", "main_8c.html#a8b6785ef32666c04c075eb015c743f59", null ],
    [ "adc_value", "main_8c.html#af766dc321c1bd2f31037d384abca2288", null ],
    [ "leds", "main_8c.html#aae0cfe7855f07b17d14b41626331e12e", null ],
    [ "overflow_count", "main_8c.html#a73652e8bd08825328d6151cccf174295", null ],
    [ "rf_driver", "main_8c.html#a4f43e679b031a869dce374f1cbf783ef", null ],
    [ "valor", "main_8c.html#a83201786792501b53e667771949a8129", null ],
    [ "vidas", "main_8c.html#ad742903c7f4c72d558becbaeb67fd3b3", null ],
    [ "vivo", "main_8c.html#abbb564a8fcc42dc72e2a9aaa1b56773c", null ]
];