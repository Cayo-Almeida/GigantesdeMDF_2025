var searchData=
[
  ['valor_0',['valor',['../main_8c.html#a83201786792501b53e667771949a8129',1,'main.c']]],
  ['vidas_1',['vidas',['../main_8c.html#ad742903c7f4c72d558becbaeb67fd3b3',1,'main.c']]],
  ['vivo_2',['vivo',['../main_8c.html#abbb564a8fcc42dc72e2a9aaa1b56773c',1,'main.c']]]
];
