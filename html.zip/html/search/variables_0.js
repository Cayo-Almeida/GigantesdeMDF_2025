var searchData=
[
  ['adc_5fflag_0',['adc_flag',['../main_8c.html#a8b6785ef32666c04c075eb015c743f59',1,'main.c']]],
  ['adc_5fvalue_1',['adc_value',['../main_8c.html#af766dc321c1bd2f31037d384abca2288',1,'main.c']]]
];
