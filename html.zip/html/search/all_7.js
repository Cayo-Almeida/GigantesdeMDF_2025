var searchData=
[
  ['timer0_5finit_0',['timer0_init',['../main_8c.html#a99eb04bf8fed2beecfb3cb74451416c5',1,'main.c']]],
  ['timer2_5finit_1',['timer2_init',['../main_8c.html#a2cd8cee0c5bd8d8b2f528216f7dd487d',1,'main.c']]]
];
