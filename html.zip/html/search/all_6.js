var searchData=
[
  ['recebeudisparo_0',['recebeuDisparo',['../main_8c.html#a33ce7e068b28ea685c11168275b40d17',1,'main.c']]],
  ['rf_5fdriver_1',['rf_driver',['../main_8c.html#a4f43e679b031a869dce374f1cbf783ef',1,'main.c']]]
];
