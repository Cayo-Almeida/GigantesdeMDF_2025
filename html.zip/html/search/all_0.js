var searchData=
[
  ['adc_5fflag_0',['adc_flag',['../main_8c.html#a8b6785ef32666c04c075eb015c743f59',1,'main.c']]],
  ['adc_5finit_1',['adc_init',['../main_8c.html#a2b815e6730e8723a6d1d06d9ef8f31c0',1,'main.c']]],
  ['adc_5fread_2',['adc_read',['../main_8c.html#a433119dfcbc822d888666197007a4f30',1,'main.c']]],
  ['adc_5fvalue_3',['adc_value',['../main_8c.html#af766dc321c1bd2f31037d384abca2288',1,'main.c']]]
];
