var searchData=
[
  ['recebeudisparo_0',['recebeuDisparo',['../main_8c.html#a33ce7e068b28ea685c11168275b40d17',1,'main.c']]]
];
