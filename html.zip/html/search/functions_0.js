var searchData=
[
  ['adc_5finit_0',['adc_init',['../main_8c.html#a2b815e6730e8723a6d1d06d9ef8f31c0',1,'main.c']]],
  ['adc_5fread_1',['adc_read',['../main_8c.html#a433119dfcbc822d888666197007a4f30',1,'main.c']]]
];
