var indexSectionsWithContent =
{
  0: "afilmortv",
  1: "m",
  2: "aimrt",
  3: "alorv",
  4: "f"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Arquivos",
  2: "Funções",
  3: "Variáveis",
  4: "Definições e Macros"
};

